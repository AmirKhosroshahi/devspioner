 export const techCompanies = [
    {label: "Javascript", value:1, image: '/image/icons8-js-50.png'},
    {label: "React", value: 2, image: '/image/reactJs.svg'},
    {label: "TypeScript", value: 3, image: '/image/icons8-typescript.svg'},
    {label: "NextJS", value: 4, image: '/image/free_icon_1.svg'},
    {label: "Vue", value:5, image: ''},
    {label: "Php", value: 6, image: '/image/icons8-php-logo.svg'},
    {label: "C#", value: 7, image: ''},
    {label: "Figma", value: 8, image: '/image/figma.svg'},
    {label: "Photoshop", value: 9, image: ''},
    {label: "Bootstrap", value:10, image: '/image/icons8-bootstrap-42.png'},
    {label: "Jquery", value: 11, image: '/image/icons8-jquery.svg'},
    {label: "Node", value:12, image: '/image/icons8-jquery.svg'},
];             