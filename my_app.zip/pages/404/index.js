import React from 'react';
import Styles from './page404.module.scss'
const Index = () => {

    return (
        <div className={Styles.page404}>
           <i></i>
        </div>
    );
};

export default Index;