import React from 'react';
import LoginAdminSite from "../../components/panelAdmin/LoginAdminSite/LoginAdminSite";

const LogonAdmin = () => {
    return (
       <LoginAdminSite/>
    );
};

export default LogonAdmin;