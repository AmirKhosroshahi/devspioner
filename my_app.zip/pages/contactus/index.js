
import ContactUs from '../../components/ContactUs/ContactUs'
const Index = () => {
    return (
        <div>
            <ContactUs/>
        </div>
    );
};




export default Index;