import React from 'react';
import Style from './add-addmin.module.scss';
const AddAdmin = () => {
    return (
        <div>
            
        </div>
    );
};

export default AddAdmin;