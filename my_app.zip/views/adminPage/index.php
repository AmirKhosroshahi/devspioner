<?php
$getProjects = $data[0];
