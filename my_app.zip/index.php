<?php
require_once('core/APP.php');
require_once('core/CONTROLLER.php');
require_once('core/MODEL.php');
require_once ('core/AutoLode.php');
new APP;
