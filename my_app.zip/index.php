<?php


require_once('core/App.php');
require_once('core/controller.php');
require_once('core/model.php');

new App;